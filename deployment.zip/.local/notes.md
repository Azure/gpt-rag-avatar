User: 
admin@MngEnvMCAP007847.onmicrosoft.com


kill -9 $(lsof -t -i:8000)


How t run it?
uvicorn main:app --reload


Add to startup command in App Service:
uvicorn main:app --host=0.0.0.0 --port=$PORT


Examples:
https://github.com/Azure-Samples/cognitive-services-speech-sdk/blob/master/samples/js/browser/avatar/chat.html
https://github.com/Azure/gen-cv/blob/main/avatar/interactive/api/function_app.py




<h2 id="videoLabel" style="background-color: white; width: 300px;">Avatar Video</h2>
<div id="videoContainer" style="position: relative; width: 960px;">
  <div id="overlayArea" style="position: absolute;" hidden="hidden">
    <!-- Add your text or image controls here -->
    <p id="overlayText" style="font-size: large;">Live Video</p>
    <!-- <img id="overlayImage" src="your-image-source.png" alt="Overlay Image"> -->
  </div>
  <div id="remoteVideo"></div>
  <canvas id="canvas" width="1920" height="1080" style="background-color: transparent;" hidden="hidden"></canvas>
  <canvas id="tmpCanvas" width="1920" height="1080" hidden="hidden"></canvas>
</div>
<br/>
